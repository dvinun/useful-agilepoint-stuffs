﻿using Ascentn.AgilePoint.WCFClient;
using Ascentn.Workflow.Base;
using System;
using System.Net;
using System.ServiceModel;


namespace HttpClientDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                IWFWorkflowService wfService = GetWorkflowService();
                WFBaseProcessDefinition[] wFProcessDefinitions = wfService.GetProcDefs();               
                Console.ReadLine();
            }
            catch (Exception e)
            {
                Console.WriteLine("\nException Caught!");
               
            }
        }

    

        public static IWFWorkflowService GetWorkflowService()
        {
            Uri uri = new Uri("net.tcp://AP-FVZLPV2:13488/AgilePointServer/Workflow");
            IWFWorkflowService m_api;
            const string APPLICATION_NAME = "SPSIntegration";
            string SVCuserName = "agpsvc";
            string SVCPassWord = "Pass@word88";
            string SVCUserDomain = "AP-FVZLPV2";
            string svcAdminUserNameWithDomain = string.Format("{0}\\{1}", SVCUserDomain, SVCuserName);
            string imporsantorUser = "AP-FVZLPV2\\agpuser1";
            System.Net.ICredentials credentials = new NetworkCredential(SVCuserName, SVCPassWord, SVCUserDomain);
            var myBinding = new NetTcpBinding();
            string nettcpurl = "net.tcp://AP-FVZLPV2:13488/AgilePointServer/Workflow";
            string locale = "en-Us";
            m_api = new WCFWorkflowProxy(APPLICATION_NAME, "AP-FVZLPV2", locale, imporsantorUser, credentials, myBinding, nettcpurl, svcAdminUserNameWithDomain);
            string authenticatedUserName = m_api.CheckAuthenticated();
            return m_api;
        }
    }
}
